<!-- this is just a load of junk -->
<link rel="stylesheet" type="text/css" href="scripts/jquery/advancedslider/css/base/advanced-slider-base.css" />
<link rel="stylesheet" type="text/css" href="scripts/jquery/advancedslider/css/minimal-small/minimal-small.css" />
<!-- <script type="text/javascript" src="scripts/jquery/advancedslider/js/jquery-1.7.2.min.js"></script> -->
<script type="text/javascript" src="scripts/jquery/advancedslider/js/jquery.easing.1.3.min.js"></script>
<!--[if IE]><script type="text/javascript" src="scripts/jquery/advancedslider/js/excanvas.compiled.js"></script><![endif]-->
<script type="text/javascript" src="scripts/jquery/advancedslider/js/jquery.advancedSlider.min.js"></script>

