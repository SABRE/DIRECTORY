<?

	/*==================================================================*\
	######################################################################
	#                                                                    #
	# Copyright 2005 Arca Solutions, Inc. All Rights Reserved.           #
	#                                                                    #
	# This file may not be redistributed in whole or part.               #
	# eDirectory is licensed on a per-domain basis.                      #
	#                                                                    #
	# ---------------- eDirectory IS NOT FREE SOFTWARE ----------------- #
	#                                                                    #
	# http://www.edirectory.com | http://www.edirectory.com/license.html #
	######################################################################
	\*==================================================================*/

	# ----------------------------------------------------------------------------------------------------
	# * FILE: /theme/default/body/faq.php
	# ----------------------------------------------------------------------------------------------------

?>	

	<div class="content content-full">
        
		<div class="content-main">
			<? include(system_getFrontendPath("general.php")); ?>
		</div>
		
		<? include(system_getFrontendPath("banner_bottom.php")); ?>
	</div>